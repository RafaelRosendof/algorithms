#include <string>
#include <vector>

int resolverExpressao(std::vector<std::string>);