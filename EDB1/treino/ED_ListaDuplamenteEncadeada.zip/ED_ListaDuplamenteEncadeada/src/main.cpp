#include <iostream>
#include "ListaDuplamenteEncadeada.h"

int main()
{
    ListaDuplamenteEncadeada l;

    std::cout << "Tamanho " << l.tamanho() << std::endl;

    return 0;
}