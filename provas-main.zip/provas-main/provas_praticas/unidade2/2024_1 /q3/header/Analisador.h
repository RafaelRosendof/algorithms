#include <string>

class Analisador
{
public:
    Analisador();
    bool eBemFormada(std::string);
};
