#include <iostream>
int main() 
{
  std::cout << "Esta questão não tem main; use o comando make run-test para rodar os testes." << std::endl;
  
  return 0;
}
