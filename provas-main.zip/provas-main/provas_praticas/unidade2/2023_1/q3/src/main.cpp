#include <iostream>
#include "../include/ListaEncadeada.h"
int main() 
{
  ListaEncadeada lista;
  
  std::cout << "Esta questão não tem main; use o comando make run-test para rodar os testes." << std::endl;
  std::cout << lista.tamanho();
  return 0;
}
