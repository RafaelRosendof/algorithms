#include "Inversion.h"

int countInversions(int v[], int size)
{
	return -1;
}
