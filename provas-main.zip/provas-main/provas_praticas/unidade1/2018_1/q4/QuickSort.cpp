#include "Sort.h"
#include <iostream>

inline void swap(int& a, int& b)
{
	int aux = a;
	a = b;
	b = aux;
}

inline int medianOfThree(int v[], int left, int right)
{
    return -1;
}

void qSort(int v[], int left, int right)
{
}

void sort(int v[], int size)
{
	qSort(v, 0, size-1);
}
