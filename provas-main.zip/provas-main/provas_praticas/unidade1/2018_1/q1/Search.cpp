#include "Search.h"
#include <iostream>

int findRightmost(int v[], int size, int key)
{
	return -1;
}
