#include "Sum3.h"

bool existsSum3(int v[], int size, int sum)
{
	return false;
}
