#include "Inversion.h"

int countInversions(int v[], int size)
{
	//TODO Implementar esta função
	return -1;
}