#include "Sort.h"

void sort(int v[], int size)
{
	//TODO Implementar esta função
}