#include "Sort.h"
#include <iostream>

void merge(int v[], int left, int mid, int right)
{
}

void mergesort(int v[], int left, int right)
{
}

void sort(int v[], int size)
{
	mergesort(v, 0, size-1);
}
