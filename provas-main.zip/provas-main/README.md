# Provas

Neste repositório, estão disponibilizadas as provas práticas e teóricas criadas pelo prof. Eiji Adachi para a disciplina IMD0029 - Estruturas de Dados Básicas I .

